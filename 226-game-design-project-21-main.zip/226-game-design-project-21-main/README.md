# Keyboard-Warriors
A typing/fighting platformer in which you have to traverse across a secret laboratory in your attempt to escape.

You will have to go up against failed experiments blocking your path and in order to get past them, you have to type the commands you want to use to fight them.

i.e. By pressing the TAB button you can switch to the fighting mode, where you can type commands such as "PUNCH", "KICK" etc.. to fight back..

The game is in a very early prototype, at this stage we are unsure if we will ever come back to update it. But if you would like to try the demo, click the itch.io link below!

## Link to Play
https://mixtapemagic.itch.io/keyboard-warriors
